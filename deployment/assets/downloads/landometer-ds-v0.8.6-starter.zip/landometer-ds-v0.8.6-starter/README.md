# Landometer Design System v0.8.6 implementation starter

**Release:** `landometer-design-system-v0.8.6-public.2`<br>
**Public package revision:** 2

This archive contains exactly these eight files:

- `README.md`
- `build-card-template.yaml`
- `component-recipes.md`
- `voice-recipes.md`
- `reference-fixtures.json`
- `landometer-tokens.css`
- `landometer-tokens.json`
- `landometer-tokens.ts`

Start with `build-card-template.yaml`, then use the token files and only the recipes required by the selected profile. The fixtures are synthetic and local-only.

The Public Specification, AI skill, release manifest, and checksums are separate release files:

- Public Specification: https://montri-th.github.io/Landometer/assets/downloads/landometer-design-system-v0.8.6-public.md
- Release manifest: https://montri-th.github.io/Landometer/assets/downloads/landometer-public-release-v0.8.6.json
- Checksums: https://montri-th.github.io/Landometer/assets/downloads/SHA256SUMS.txt

This starter contains no image, logo, font binary, dataset, credential, connector, script, workflow, or deployment authority. Generated Schema 6/preflight conformance remains pending; this archive does not certify production readiness.
